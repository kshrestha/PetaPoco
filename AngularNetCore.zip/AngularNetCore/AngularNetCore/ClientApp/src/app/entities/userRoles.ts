
export class UserRoles {
  public IsAuthenticated: boolean = false;

  setRoles(roles: string[]) {
    this.IsAuthenticated = true;
  }
}

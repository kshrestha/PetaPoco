"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var UserRoles = /** @class */ (function () {
    function UserRoles() {
        this.IsAuthenticated = false;
    }
    UserRoles.prototype.setRoles = function (roles) {
        this.IsAuthenticated = true;
    };
    return UserRoles;
}());
exports.UserRoles = UserRoles;
//# sourceMappingURL=userRoles.js.map
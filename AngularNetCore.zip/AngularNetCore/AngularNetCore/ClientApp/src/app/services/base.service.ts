import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export abstract class BaseService {

  protected serviceUrl: string;

  constructor(private httpClient: HttpClient) {
    this.serviceUrl = "./";
  }

  search<T>(method: string, params?: any) {
    let url = this.serviceUrl + method;
    return this.httpClient.get<T>(url, { params });
  }

  get<T>(method: string, id?: number) {
    let url = this.serviceUrl + method;
    if (id != null) {
      url = url + '/' + id;
    }
    return this.httpClient.get<T>(url);
  }

  post<T>(method: string, data: any) {
    return this.httpClient.post<T>(this.serviceUrl + method, data);
  }

  put<T>(method: string, id: number, data: any) {
    return this.httpClient.put<T>(this.serviceUrl + method + '/' + id, data);
  }

  delete(method: string, id: number) {
    let url = this.serviceUrl + method + '/' + id;
    return this.httpClient.delete(url);
  }
}

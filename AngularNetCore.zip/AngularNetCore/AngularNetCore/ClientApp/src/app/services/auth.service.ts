import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { AsyncSubject, Subject, Observable, forkJoin } from 'rxjs';
import { Router } from '@angular/router';
import { UserRoles} from '@app/entities'


@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private _authToken: any;
  private _currentUser: any;
  public _authGuard: UserRoles = new UserRoles();
  public _userRoles$ = new AsyncSubject();
  private authObservable = new Observable<any>();

  constructor(private httpClient: HttpClient, private router: Router) { }

  authenticateUser(): Observable<UserRoles> {
    var subject = new Subject<UserRoles>();
    if (this._authGuard.IsAuthenticated) {
      setTimeout(() => {
          subject.next(this._authGuard);
        },
        100);
    } else {
      this.authObservable = this.httpClient.get('./Home/Authenticate');
      forkJoin(
        this.authObservable
      ).subscribe(([authData]) => {
        if (authData) {
          this._authGuard.setRoles(authData.user.Roles);
          this.setAuthData(authData);
          subject.next(this._authGuard);
        } else {
          subject.next(this._authGuard);
          this.router.navigate(['/noaccess']);
        }
      });
    }
    return subject.asObservable();
  }

  setAuthData(authData: any) {
    this._authToken = authData.user.Token;
    this._currentUser = authData.user.User;
    this._userRoles$.next(this._authGuard);
    this._userRoles$.complete();
  }

  getToken() {
    return this._authToken;
  }
}

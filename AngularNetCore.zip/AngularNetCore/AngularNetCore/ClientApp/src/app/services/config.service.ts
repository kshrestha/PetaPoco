import { Injectable } from '@angular/core';
import { BaseService } from './base.service';
@Injectable({
  providedIn: 'root'
})
export class ConfigService extends BaseService {

  private settings: Record<string, string>;

  init(): Promise<any> {
    const promise = this.get('Home/Settings')
      .toPromise()
      .then((s: Record<string, string>) => {
        this.settings = s;
        return s;
      });
    return promise;
  }

  getExternalUrl(): string {
    return this.settings['ExternalUrl'];
  }

}

import { BrowserModule } from '@angular/platform-browser';
import { NgModule, APP_INITIALIZER } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { RouterModule } from '@angular/router';

import { ApiInterceptor, AuthGuard } from "@app/shared";
import { ConfigService } from "@app/services";

import { AppComponent } from '@app/app.component';
import { NavMenuComponent } from '@app/nav-menu';
import { HomeComponent } from '@app/home/home.component';
import { CounterComponent } from '@app/counter/counter.component';
import { FetchDataComponent } from '@app/fetch-data/fetch-data.component';

@NgModule({
  declarations: [
    AppComponent,
    NavMenuComponent,
    HomeComponent,
    CounterComponent,
    FetchDataComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'ng-cli-universal' }),
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot([
      { path: '', component: HomeComponent, pathMatch: 'full', canActivate: [AuthGuard], data: { role: 'IsAuthenticated' }, },
      { path: 'counter', component: CounterComponent, canActivate: [AuthGuard], data: { role: 'IsAuthenticated' }, },
      { path: 'fetch-data', component: FetchDataComponent, canActivate: [AuthGuard], data: { role: 'IsAuthenticated' }, },
    ])
  ],
  providers: [
    { provide: HTTP_INTERCEPTORS, multi: true, useClass: ApiInterceptor },
    { provide: APP_INITIALIZER, multi: true, deps: [ConfigService], useFactory: (configService) => () => configService.init() },
    ],
  bootstrap: [AppComponent]
})
export class AppModule { }

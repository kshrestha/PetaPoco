import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { AuthService } from '@app/services';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {

  constructor(private authService: AuthService, private router: Router) { }

  canActivate(route: ActivatedRouteSnapshot): Observable<boolean> {
    let roles: Array<string> = [];
    if (!Array.isArray(route.data["role"])) {
      roles = [route.data["role"] as string];
    } else {
      roles = route.data["role"] as Array<string>;
    }

    return this.authService.authenticateUser().pipe(
      map((response: any) => {
        if (roles.some((e) => response[e])) {
          return true;
        } else {
          this.router.navigate(['/noaccess']);
          return false;
        }
      })
    );
  }

}

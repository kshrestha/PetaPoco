import { Injectable } from '@angular/core';
import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { finalize, catchError } from 'rxjs/operators';
import { HttpHeaders, HttpErrorResponse } from '@angular/common/http';
import { AuthService, LoadingService } from '@app/services';
@Injectable({
  providedIn: 'root'
})
export class ApiInterceptor implements HttpInterceptor {
  activeRequests: number = 0;

  constructor(private authService: AuthService, private loadingService: LoadingService) {
  }

  private handleError(err: HttpErrorResponse): Observable<any> {
    if (err.status === 401 || err.status === 403) {
      console.log("You do not have permission to perform this task. Please contact your administrator for access.");
      return of(err.message);
    } else if (err.status === 422) {
      console.log(err.error, null, true);
      return of(err.message);
    } else if (err.status === 500 || (err.status === 0 && err.name === 'HttpErrorResponse')) {
      console.log("There was an error performing this task. Please contact your administrator.");
      throw err;
    }
    return throwError(err);
  }

  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    if (this.authService.getToken()) {
      request = request.clone({
        withCredentials: true,
        headers: new HttpHeaders({
          'Token': this.authService.getToken()
        })
      });
    }


    request = request.clone({
      withCredentials: true
    });
    request.headers.append('Content-Type', 'application/json');

    if (this.activeRequests === 0) {
      this.loadingService.startLoading();
    }
    this.activeRequests++;

    return next.handle(request).pipe(
      finalize(() => {
        this.activeRequests--;
        if (this.activeRequests === 0) {
          this.loadingService.stopLoading();
        }
      }),
      catchError(err => this.handleError(err))
    );
  }
}

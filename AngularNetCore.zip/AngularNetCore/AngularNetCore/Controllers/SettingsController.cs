﻿using System.Threading.Tasks;
using Business.Interfaces;
using Core.DTO;
using Microsoft.AspNetCore.Mvc;

namespace AngularNetCore.Controllers
{
    [ApiController]
    public class SettingsController : ControllerBase
    {
        private readonly ISettingsBL _settingsBl;
        private const string GetSettingByIdRouteName = "GetSettingById";

        public SettingsController
        (
            ISettingsBL settingsBl
        )
        {
            _settingsBl = settingsBl;
        }

        [HttpGet("Settings")]
        public async Task<IActionResult> GetSettings()
        {
            var settings = await _settingsBl.GetSettingsAsync();
            if (settings != null && settings.Count > 0)
            {
                return Ok(settings);
            }

            return NotFound();
        }

        [HttpGet("Settings/{settingId}", Name = GetSettingByIdRouteName)]
        public async Task<IActionResult> GetSettingByIdAsync(int settingId)
        {
            var setting = await _settingsBl.GetSettingAsync(settingId);
            if (setting != null)
            {
                return Ok(setting);
            }

            return NotFound();
        }

        [HttpPut("Settings/{settingId}")]
        public async Task<IActionResult> PutSettingAsync(int settingId, Settings setting)
        {
            if (settingId != setting.SettingId)
            {
                return BadRequest();
            }

            await _settingsBl.UpdateSettingAsync(setting);
            return NoContent();
        }

        [HttpPost("Settings")]
        public async Task<IActionResult> PostSettingAsync(Settings setting)
        {
            var id = await _settingsBl.AddNewSettingsAsync(setting);
            setting.SettingId = id;
            return CreatedAtRoute(GetSettingByIdRouteName, new { settingId = id }, setting);
        }

        [HttpDelete("Settings/{settingId}")]
        public async Task<IActionResult> DeleteSettingByIdAsync(int settingId)
        {
            var wasRemoved = await _settingsBl.DeleteSettingAsync(settingId);
            if (wasRemoved)
            {
                return NoContent();
            }

            return NotFound();
        }
    }
}

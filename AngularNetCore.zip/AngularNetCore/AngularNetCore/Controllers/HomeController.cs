﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

namespace AngularNetCore.Controllers
{
    [ApiController]
    public class HomeController : ControllerBase
    {

        [HttpGet("Home/Authenticate")]
        public IActionResult Authenticate()
        {
            var user = new
            {
                Token = "safjasdf2341432$^$^$^$&$&hkhkhlj",
                Roles = new [] { "user", "admin" }
            };

            HttpContext.Response.Headers.Add("token", user.Token);
            var result = new Dictionary<string, object>
            {
                {"user", user}
            };

            return Ok(result);
        }


        [HttpGet("Home/Settings")]
        public IActionResult Settings()
        {
            return Ok(new Dictionary<string, string>() {{"externalUrl", "http://ext.html"}});
        }
    }
}

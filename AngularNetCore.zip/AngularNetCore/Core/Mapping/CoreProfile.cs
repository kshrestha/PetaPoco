﻿using AutoMapper;

namespace Core.Mapping
{
    public class CoreProfile : Profile
    {
        public CoreProfile()
        {
            CreateMap<Models.Settings, DTO.Settings>();
            CreateMap<DTO.Settings, Models.Settings>();
        }
    }
}
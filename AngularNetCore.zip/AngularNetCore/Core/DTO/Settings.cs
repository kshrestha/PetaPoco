﻿using System;

namespace Core.DTO
{
    public class Settings
    {
        public int SettingId { get; set; }
        public int ApplicationId { get; set; }
        public string Name { get; set; }
        public string Value { get; set; }
        public string CreateUser { get; set; }
        public DateTime CreateDate { get; set; }
        public string ChangeReason { get; set; }
    }
}
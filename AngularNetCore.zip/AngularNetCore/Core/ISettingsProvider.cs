﻿namespace Core
{
    public interface ISettingsProvider
    {
        string ConnectionString { get; }
    }
}
﻿using System;

namespace Core
{
    public interface INowProvider
    {
        DateTime GetNow();
    }
}
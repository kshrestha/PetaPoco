﻿using Autofac;
using AutoMapper;
using Core.Mapping;

namespace Core
{
    public class CoreMappingModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.Register(ctx => BuildMapperConfiguration());
            builder.Register(ctx => ctx.Resolve<MapperConfiguration>().CreateMapper()).As<IMapper>().SingleInstance();

        }

        public static MapperConfiguration BuildMapperConfiguration()
        {
            return new MapperConfiguration(cfg => { cfg.AddProfile<CoreProfile>(); });
        }
    }
}
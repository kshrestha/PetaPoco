﻿using System;

namespace Core
{
    public class NowProvider : INowProvider
    {
        public DateTime GetNow()
        {
            return DateTime.Now;
        }
    }
}
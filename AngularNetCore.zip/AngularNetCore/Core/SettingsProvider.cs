﻿namespace Core
{
    public class SettingsProvider : ISettingsProvider
    {
        public string ConnectionString { get; }
    }
}
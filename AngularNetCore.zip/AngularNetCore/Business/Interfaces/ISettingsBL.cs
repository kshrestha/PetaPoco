﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Business.Interfaces
{
    public interface ISettingsBL
    {
        Task<List<Core.DTO.Settings>> GetSettingsAsync();
        Task<Core.DTO.Settings> GetSettingAsync(int id);
        Task<int> AddNewSettingsAsync(Core.DTO.Settings setting);
        Task UpdateSettingAsync(Core.DTO.Settings setting);
        Task<bool> DeleteSettingAsync(int id);
    }
}
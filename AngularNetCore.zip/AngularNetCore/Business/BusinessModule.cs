﻿using Autofac;
using Business.Interfaces;

namespace Business
{
    public class BusinessModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<SettingsBL>().As<ISettingsBL>().InstancePerLifetimeScope();
        }
    }
}
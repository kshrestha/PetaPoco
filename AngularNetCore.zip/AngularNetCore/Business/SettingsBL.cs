﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Business.Interfaces;
using Core.Models;
using DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Business
{
    public class SettingsBL : ISettingsBL
    {
        private readonly IAppContext _context;
        private readonly IMapper _mapper;

        public SettingsBL(IAppContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        public async Task<List<Core.DTO.Settings>> GetSettingsAsync()
        {
            var query = _context.Settings;
            return await _mapper.ProjectTo<Core.DTO.Settings>(query).ToListAsync();
        }

        public async Task<Core.DTO.Settings> GetSettingAsync(int id)
        {
            var query = _context.Settings.Where(v => v.Settingid == id);
            return await _mapper.ProjectTo<Core.DTO.Settings>(query).FirstOrDefaultAsync();
        }

        public async Task<int> AddNewSettingsAsync(Core.DTO.Settings setting)
        {
            var entity = _mapper.Map<Settings>(setting);
            _context.Settings.Add(entity);
            await _context.SaveChangesAsync();
            return entity.Settingid;
        }

        public async Task UpdateSettingAsync(Core.DTO.Settings setting)
        {
            var entity = await _context.Settings.SingleOrDefaultAsync(v => v.Settingid == setting.SettingId);
            if (entity != null)
            {
                _mapper.Map<Core.DTO.Settings, Settings>(setting, entity);
                await _context.SaveChangesAsync();
            }

        }

        public async Task<bool> DeleteSettingAsync(int id)
        {
            var valveType = await _context.Settings.FirstOrDefaultAsync(v => v.Settingid == id);
            if (valveType != null)
            {
                _context.Settings.Remove(valveType);
                return (await _context.SaveChangesAsync()) > 0;
            }

            return false;
        }
    }
}

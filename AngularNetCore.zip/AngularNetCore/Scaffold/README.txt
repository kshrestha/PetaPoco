﻿*** How to scaffold EFCore ***

1. Open the Package Manager Console window in Visual Studio and install the following NuGet packages in the EFCoreScaffolding project.
	- Install-Package Microsoft.EntityFrameworkCore.SqlServer
	- Install-Package Microsoft.EntityFrameworkCore.Tools
	
2. Install Microsoft.EntityFrameworkCore.SqlServer NuGet package in the DataAccess project.

3. Set the EFCoreScaffolding project as your startup project.

4. Enter the following command (Note that the solution must currently be building successfully for it to work):

	Scaffold-DBContext "Data Source=nndessqapp25d\nndessqapp25d;Initial Catalog=ConfigManager;Integrated Security=True" Microsoft.EntityFrameworkCore.SqlServer -OutputDir Models -Force -Project Core -Context AppContextBase -Tables "Settings" 
	
5. All models for the tables will be generated to DataAccess/Models

6. The AppContextBase class is also generated to the above folder. This needs to be moved to DataAccess. (Make sure to delete the generated copy in Core/Models.)

7. Change the namespace in AppContextBase.cs to DataAccess.

8. Delete the OnConfiguring method in AppContextBase.cs as the AppContext.cs class implements this method.
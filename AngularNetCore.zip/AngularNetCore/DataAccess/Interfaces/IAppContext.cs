﻿using System.Threading.Tasks;
using Core.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;

namespace DataAccess.Interfaces
{
    public interface IAppContext
    {
        DbSet<T> DbSet<T>() where T : class;

        EntityEntry<T> Entry<T>(T entity) where T : class;

        Task<int> SaveChangesAsync();

        DbSet<Settings> Settings { get; set; }
    }
}
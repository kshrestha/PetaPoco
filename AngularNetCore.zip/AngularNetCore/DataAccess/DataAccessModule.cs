﻿using Autofac;
using Core;
using DataAccess.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace DataAccess
{
    public class DataAccessModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<AppContext>().As<IAppContext>().InstancePerLifetimeScope();
            builder.Register((context, param) =>
                {
                    var nowProvider = context.Resolve<INowProvider>();

                    var settings = context.Resolve<ISettingsProvider>();
                    var connectionString = settings.ConnectionString;

                    var options = new DbContextOptionsBuilder<AppContextBase>().UseSqlServer(connectionString)
                        .Options;

                    return new AppContext(options, nowProvider);
                }
            ).As<IAppContext>().InstancePerLifetimeScope();
        }
    }
}
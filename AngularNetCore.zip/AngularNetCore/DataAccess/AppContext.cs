﻿using System;
using System.Linq;
using System.Threading.Tasks;
using Core;
using Microsoft.EntityFrameworkCore;
using Core.Models;
using DataAccess.Interfaces;

namespace DataAccess
{
    public class AppContext : AppContextBase, IAppContext
    {
        private readonly INowProvider _nowProvider;

        internal const string CreateUserId = "CreateUserId";
        internal const string CreateDateTime = "CreateDateTime";
        internal const string UpdateUserId = "UpdateUserId";
        internal const string UpdateDateTime = "UpdateDateTime";

        public AppContext(DbContextOptions<AppContextBase> options, INowProvider nowProvider) : base(options)
        {
            _nowProvider = nowProvider;
        }

        public DbSet<T> DbSet<T>() where T : class
        {
            return base.Set<T>();
        }

        public async Task<int> SaveChangesAsync()
        {
            SetAuditFields();
            return await base.SaveChangesAsync();
        }

        private void SetAuditFields()
        {
            var userId = 8888;

            var modifiedEntries = ChangeTracker.Entries()
                .Where(e => e.State == EntityState.Added || e.State == EntityState.Modified);

            foreach (var entry in modifiedEntries)
            {
                var timestamp = _nowProvider.GetNow();
                var entityType = entry.Context.Model.FindEntityType(entry.Entity.GetType());

                if (entry.State == EntityState.Added)
                {
                    if (entityType.FindProperty(CreateUserId) != null)
                    {
                        entry.Property(CreateUserId).CurrentValue = userId;
                    }

                    if (entityType.FindProperty(CreateDateTime) != null)
                    {
                        entry.Property(CreateDateTime).CurrentValue = timestamp;
                    }
                }

                if (entityType.FindProperty(UpdateUserId) != null)
                {
                    entry.Property(UpdateUserId).CurrentValue = userId;
                }

                if (entityType.FindProperty(UpdateDateTime) != null)
                {
                    entry.Property(UpdateDateTime).CurrentValue = timestamp;
                }
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            TestSetup(modelBuilder);
        }

        protected virtual void TestSetup(ModelBuilder modelBuilder)
        {
            //overridden in TestContext
        }
    }
}

﻿using Core.Models;
using Microsoft.EntityFrameworkCore;

namespace DataAccess
{
    public partial class AppContextBase : DbContext
    {
        public AppContextBase()
        {
        }

        public AppContextBase(DbContextOptions<AppContextBase> options)
            : base(options)
        {
        }

        public virtual DbSet<Settings> Settings { get; set; }
        
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Settings>(entity =>
            {
                entity.ToTable("Settings", "cm");

                entity.Property(e => e.Settingid).HasColumnName("settingid");

                entity.Property(e => e.ApplicationId).HasColumnName("applicationId");

                entity.Property(e => e.ChangeReason).HasColumnName("changeReason");

                entity.Property(e => e.CreateDate).HasColumnName("createDate");

                entity.Property(e => e.CreateUser).HasColumnName("createUser");

                entity.Property(e => e.Name).HasColumnName("name");

                entity.Property(e => e.Value).HasColumnName("value");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}

﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using DataAccess;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Newtonsoft.Json;

namespace DBApiTests.Support
{
    public class CollaborationTestBase
    {
        protected TestSettingsProvider _testSettingsProvider;
        protected TestNowProvider _testNowProvider;
        protected HttpClient _client;

        [TestInitialize]
        public async Task SetupAsync()
        {
            var connectionString = $"DataSource={Guid.NewGuid()};Mode=Memory;Cache=Shared";

            _testSettingsProvider = new TestSettingsProvider(connectionString);
            _testNowProvider = new TestNowProvider();
            _client = await GetTestClient(_testNowProvider, _testSettingsProvider);
        }

        protected DateTime SetNext(DateTime nextDateTime)
        {
            _testNowProvider.SetNextNow(nextDateTime);
            return nextDateTime;
        }

        protected async Task<T> GetAsync<T>(string url)
        {
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            var response = await _client.SendAsync(request);
            if (!response.IsSuccessStatusCode)
            {
                if(response.StatusCode == HttpStatusCode.NotFound)
                {
                    return default(T);
                }
                throw new Exception($"Get Request returned {response.StatusCode}");
            }
            var dataJson = await response.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<T>(dataJson);
            return result;
        }

        protected async Task<DateTime> PutAsync(object data, string url, DateTime dateTime)
        {
            var nextDateTime = SetNext(dateTime);
            var dataJson = JsonConvert.SerializeObject(data);
            var request = new HttpRequestMessage(HttpMethod.Put, url);
            request.Content = new StringContent(dataJson, Encoding.UTF8, "application/json");
            var response = await _client.SendAsync(request);
            if (response.StatusCode != HttpStatusCode.NoContent)
            {
                throw new Exception($"Put Request returned {response.StatusCode}");
            }
            return nextDateTime;
        }

        protected async Task<(T, DateTime)> PostAsync<T>(T data, string url, DateTime dateTime)
        {
            var nextDateTime = SetNext(dateTime);
            var result = await PostAsync<T, T>(data, url);
            return (result, nextDateTime);
        }

        protected async Task<(T1, DateTime)> PostAsync<T, T1>(T data, string url, DateTime dateTime)
        { 
            var nextDateTime = SetNext(dateTime);
            var result = await PostAsync<T, T1>(data, url);
            return (result, nextDateTime);
        }

        private async Task<T1> PostAsync<T, T1>(T data, string url)
        {
            var dataJson = JsonConvert.SerializeObject(data);
            var request = new HttpRequestMessage(HttpMethod.Post, url);
            request.Content = new StringContent(dataJson, Encoding.UTF8, "application/json");
            var response = await _client.SendAsync(request);
            if (response.StatusCode != HttpStatusCode.Created)
            {
                throw new Exception($"Post Request did not return 'Created' but rather returned {response.StatusCode}");
            }
            var resultJson = await response.Content.ReadAsStringAsync();
            var result = JsonConvert.DeserializeObject<T1>(resultJson);
            return result;
        }

        protected async Task<HttpStatusCode> DeleteAsync(string url)
        {
            var request = new HttpRequestMessage(HttpMethod.Delete, url);
            var response = await _client.SendAsync(request);
            return response.StatusCode;
        }

        protected async Task<HttpClient> GetTestClient(TestNowProvider nowProvider, TestSettingsProvider settingsProvider)
        {
            var testServer = await TestServerBuilder.CreateServer<TestStartup>(nowProvider, settingsProvider);
            return testServer.GetTestClient();
        }

        protected async Task<(SqliteConnection, string, DateTime?)> InitializeDb
        (
            string userId = null, 
            DateTime? dateTime = null, 
            List<IEnumerable<object>> entityLists = null
        )
        {
            if (dateTime.HasValue)
            {
                _testNowProvider.SetNextNow(dateTime.Value);
            }

            var connection = new SqliteConnection(_testSettingsProvider.ConnectionString);
            connection.Open();
            var options = new DbContextOptionsBuilder<AppContextBase>().UseSqlite(connection).Options;
            var context = new TestAppContext(options, _testNowProvider);
            
            context.Database.EnsureCreated();
            
            if (entityLists != null && entityLists.Count != 0)
            {
                foreach (var itemList in entityLists)
                {
                    context.AddRange(itemList);
                }
                await context.SaveChangesAsync();
            }
            return (connection, userId, dateTime);
        }
    }
}

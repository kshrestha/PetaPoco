﻿using System;
using Core;

namespace DBApiTests.Support
{
    public class TestNowProvider : INowProvider
    {
        private DateTime _nextNow = DateTime.Now;

        public void SetNextNow(DateTime nextNow)
        {
            _nextNow = nextNow;
        }

        public DateTime GetNow()
        {
            return _nextNow;
        }
    }
}

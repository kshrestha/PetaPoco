﻿using Core;
using DataAccess;
using Microsoft.EntityFrameworkCore;

namespace DBApiTests.Support
{
    public class TestAppContext : AppContext
    {
        public TestAppContext(DbContextOptions<AppContextBase> options, INowProvider nowProvider) 
            : base(options, nowProvider)
        {
          
        }

        protected override void TestSetup(ModelBuilder modelBuilder)
        {
         
        }
    }
}

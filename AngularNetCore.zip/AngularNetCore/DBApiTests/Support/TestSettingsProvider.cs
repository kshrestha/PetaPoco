﻿using Core;

namespace DBApiTests.Support
{
    public class TestSettingsProvider : ISettingsProvider
    {
        public TestSettingsProvider(string connectionString)
        {
            ConnectionString = connectionString;
        }

        public string ConnectionString { get; }
    }
}
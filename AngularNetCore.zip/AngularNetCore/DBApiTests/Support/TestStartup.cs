﻿using AngularNetCore;
using Autofac;
using Core;
using DataAccess;
using DataAccess.Interfaces;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Data.Sqlite;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace DBApiTests.Support
{
    public class TestStartup : Startup
    {
        public TestStartup(IConfiguration configuration) : base(configuration)
        {
        }

        protected override void ConfigureContainerOverriddenForTest(ContainerBuilder builder)
        {
            //base.ConfigureServicesOverriddenForTest registrations are registered with Test classes in TestServerBuilder
            builder.Register((context, param) =>
                {
                    var configSettings = context.Resolve<ISettingsProvider>();

                    var connectionString = configSettings.ConnectionString;
                    var connection = new SqliteConnection(connectionString);
                    connection.Open();
                    var options = new DbContextOptionsBuilder<AppContextBase>().UseSqlite(connection).Options;

                    var nowProvider = context.Resolve<INowProvider>();
                    return new TestAppContext(options, nowProvider);
                }
            ).As<IAppContext>().InstancePerLifetimeScope();
        }

        protected override void ConfigureSpaServices(IServiceCollection services)
        {
           
        }

        protected override void ConfigureSpa(IApplicationBuilder app, IWebHostEnvironment env)
        {

        }
    }
}

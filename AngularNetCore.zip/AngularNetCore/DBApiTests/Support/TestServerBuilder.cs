﻿using System.Threading.Tasks;
using Autofac;
using Autofac.Extensions.DependencyInjection;
using Core;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.TestHost;
using Microsoft.Extensions.Hosting;

namespace DBApiTests.Support
{
    public class TestServerBuilder
    {
        public static async Task<IHost> CreateServer<TStartup>(INowProvider nowProvider, ISettingsProvider settingsProvider) where TStartup : class
        {
            var hostBuilder = new HostBuilder()
                .UseServiceProviderFactory(new AutofacServiceProviderFactory())
                .ConfigureWebHost(webHost =>
                {
                    webHost.UseStartup<TStartup>();
                    webHost.UseTestServer();
                })
                .ConfigureContainer<ContainerBuilder>(builder =>
                {
                    builder.Register(c => settingsProvider).As<ISettingsProvider>().SingleInstance();
                    builder.Register(c => nowProvider).As<INowProvider>().SingleInstance();
                });

            var host = await hostBuilder.StartAsync();
            return host;
        }
    }
}

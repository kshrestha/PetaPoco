﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using Core.DTO;
using DBApiTests.Support;
using FluentAssertions;
using Microsoft.Data.Sqlite;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace DBApiTests
{
    [TestClass]
    public class SettingsCollaborationTests : CollaborationTestBase
    {
        private SqliteConnection _openDbConnection = null;
        private Settings _postedSetting = null;

        [TestInitialize]
        public async Task TestInitAsync()
        {
            _openDbConnection = await InitializeDbAsync();

            var newSetting = new Settings()
            {
               ApplicationId = 1,
               Name = "IsFake",
               Value = "False"
            };

            var (postedSetting, postedDateTime) =
                await PostAsync
                (
                    newSetting,
                    url: "Settings",
                    dateTime: new DateTime(2020, 03, 03, 3, 3, 3)
                );
            _postedSetting = postedSetting;
        }

        [TestCleanup]
        public void TestCleanUp()
        {
            _openDbConnection.Close();
        }

        private async Task<SqliteConnection> InitializeDbAsync()
        {
            var settings = new List<Core.Models.Settings>
            {
                new Core.Models.Settings{ Settingid = 1, ApplicationId = 1, Name = "IsTest", Value = "False"},
            };
            
            var (openDbConnection, _, _) = await InitializeDb
            (
                userId: "t11111",
                dateTime: new DateTime(2020, 01, 1, 1, 1, 1),
                entityLists: new List<IEnumerable<object>>
                {
                    settings
                }
            );
            return openDbConnection;
        }

        [TestMethod]
        public async Task GetSettingByIdAsync_GET_Returns_Correct_Setting()
        {
            //Arrange
            var openDbConnection = await InitializeDbAsync();

            // Act

            // GET all 
            var allSettings = await GetAsync<List<Settings>>
            (
                url: "Settings"
            );

            var setting = allSettings.FirstOrDefault(d => d.Name == "IsTest");

            var settingById = await GetAsync<Settings>
            (
                url: "Settings" + $"/{setting.SettingId}"
            );

            // Assert
            settingById.Should().BeEquivalentTo(setting);

            openDbConnection.Close();
        }

    }
}